﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IMS_Project.Models;
using System.Data;

namespace IMS_Project.Controllers
{
    public class EmployeeController : Controller
    {
        IMS_Entities db = new IMS_Entities();

        public ActionResult Index()
        {
            return View(db.Employees.ToList());
        }
        
        public ActionResult Create()
        {
            ViewBag.RoleID = new SelectList(db.Roles, "RoleID", "RoleName");
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(emp);
                db.SaveChanges();
                return RedirectToAction("Index", "Employee");
            }
            return View();
        }

        //Get Edit
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Employee emp = db.Employees.Single(x => x.EmpID == id);
            if (emp==null)
            {
                return HttpNotFound();
            }
            ViewBag.RoleID = new SelectList(db.Roles, "RoleID", "RoleName", emp.RoleID);
            return View("Create",emp);
        }

        //Post Edit
        [HttpPost]
        public ActionResult Edit(Employee emp)
        {
            if (ModelState.IsValid)
            {
                db.Entry(emp).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index","Employee");
            }
            ViewBag.RoleID = new SelectList(db.Roles, "RoleID", "RoleName", emp.RoleID);
            return View(emp);
        }

        //Get Details
        public ActionResult Details(int id)
        {
           Employee emp= db.Employees.Find(id);
           if (emp==null)
           {
               return HttpNotFound();
           }
           return View(emp);
        }

        //Get Delete
        public ActionResult Delete(int id)
        {
            Employee emp = db.Employees.Find(id);
            if (emp==null)
            {
                return HttpNotFound();
            }
            return View(emp);
 
        }

        //Post Delete Confirmed
        [HttpPost,ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee employee = db.Employees.Find(id);
            db.Employees.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }       
        
    }
}