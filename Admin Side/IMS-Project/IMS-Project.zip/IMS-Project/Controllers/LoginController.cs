﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IMS_Project.Models;

namespace IMS_Project.Controllers
{
    public class LoginController : Controller
    {
        IMS_Entities db = new IMS_Entities();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }        

        [HttpPost]
        public ActionResult Login(Login login)
        {
            if (ModelState.IsValid)
            {
                var model = (from m in db.Logins
                            where m.UserName == login.UserName && m.Password == login.Password
                            select m).Any();
                if (model)
                {                    
                    Session["username"] = login.UserName;
                   return RedirectToAction("Index", "Dashboard");
                }                
                 return View("Index");
                
            }
            return View("Index");
        }
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Login");
        }
    }
}