﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IMS_Project.Controllers
{
    public class DashboardController : Controller
    {
        
        public ActionResult Index()
        {
            if (HttpContext.Session["username"]!=null)
            {
                return View();                
            }
            return RedirectToAction("Index", "Login");
            

        }

        public ActionResult About()
        {
            ViewBag.SubTitle = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.SubTitle = "Your contact page.";

            return View();
        }
       
    }
}