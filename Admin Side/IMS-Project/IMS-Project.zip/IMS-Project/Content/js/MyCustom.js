﻿////Load DatePicker
//$(function () {
//    $('.datetimepicker').datepicker();
//});